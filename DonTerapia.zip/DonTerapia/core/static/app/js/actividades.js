document.getElementById('createActivity').addEventListener('click', function() {
    alert('Crear nueva actividad');
});